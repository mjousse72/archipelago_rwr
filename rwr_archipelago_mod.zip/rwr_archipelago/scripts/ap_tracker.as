// Archipelago tracker: syncs AP state with the game, detects checks, applies items and traps.

#include "tracker.as"
#include "helpers.as"
#include "query_helpers.as"
#include "log.as"
#include "ap_data.as"
#include "ap_map_rotator.as"

// State machine constants
const int AP_DISCONNECTED = 0;
const int AP_WAITING      = 1;
const int AP_RUNNING      = 2;
const int AP_ERROR        = 3;

// Co-op: per-player tracking data
class APPlayer {
	int playerId = -1;
	int characterId = -1;
	string name = "";
	bool alive = false;
	bool deathLinkKillInProgress = false;
}

// ============================================================
class APTracker : Tracker {
	protected Metagame@ m_metagame;

	// -- Map rotator reference (set after construction) --
	protected APMapRotatorCampaign@ m_mapRotator;

	// -- State machine --
	protected int m_state = AP_DISCONNECTED;
	protected int m_errorRetryCount = 0;
	protected float m_errorRetryTimer = 0.0;

	// -- Timers --
	protected float m_pollTimer = 1.0;      // first poll quickly
	protected float m_saveTimer = 30.0;
	protected float m_disconnectedMsgTimer = 0.0;
	protected float m_rpDeliveryTimer = 0.0;
	protected float m_playerScanTimer = 0.0;  // periodic co-op player rescan
	protected float m_rankSyncTimer = 0.0;    // periodic rank/XP drift correction
	protected float m_userCmdTimer = 0.0;     // overlay command poll (fast)

	// -- Constants --
	protected float POLL_INTERVAL = 3.0;
	protected float SAVE_INTERVAL = 30.0;
	protected float ERROR_RETRY_INTERVAL = 10.0;
	protected int   MAX_ERROR_RETRIES = 3;
	protected float DISCONNECTED_MSG_INTERVAL = 15.0;
	protected float RP_DELIVERY_INTERVAL = 5.0;
	protected int   RP_PER_DELIVERY = 100;
	protected float PLAYER_SCAN_INTERVAL = 2.0;  // safety net for guest joins
	protected float RANK_SYNC_INTERVAL = 15.0;   // clamp XP back to AP rank threshold
	protected float USER_CMD_INTERVAL = 0.5;     // overlay button → action latency budget

	// -- Bridge state (from ap_state.xml) --
	protected int m_lastVersion = -1;
	protected bool m_dataChanged = false;
	protected string m_slotName = "";
	protected int m_apRankLevel = 0;
	protected bool m_weaponShuffle = false;
	protected string m_weaponMode = "";     // "categories" or "individual"
	protected bool m_radioShuffle = false;
	protected bool m_radioMasterUnlocked = false;
	protected int m_rpTotal = 0;
	protected int m_xpBoost = 0;
	protected int m_rareVouchers = 0;
	protected int m_vouchersRedeemed = 0;
	protected int m_voucherBonusRP = 0;
	protected dictionary m_voucherUnlockedFiles;
	protected int m_pendingHeals = 0;
	protected int m_healsDelivered = 0;
	protected int m_trapSeverity = 1;  // 0=mild, 1=medium, 2=harsh
	protected array<string> m_notifications;
	protected bool m_deathLinkEnabled = false;
	protected bool m_deathLinkPending = false;
	protected bool m_deathLinkAcked = false;  // latch: stay true until bridge clears pending
	protected string m_deathLinkMode = "kill";  // "kill" or "random_trap"
	protected bool m_goalComplete = false;

	// -- RP Shop --
	protected bool m_rpShopEnabled = false;
	protected int m_rpShopCost = 1000;
	protected int m_rpShopPerMap = 3;
	protected dictionary m_rpShopPurchased;  // mapName -> int count

	// -- Unlocked sets (key -> true) --
	protected dictionary m_unlockedMaps;
	protected dictionary m_unlockedWeaponKeys;    // weapon file or category key
	protected dictionary m_unlockedCallFiles;     // call file
	protected dictionary m_unlockedEquipFiles;    // equipment file
	protected dictionary m_unlockedThrowFiles;    // throwable file

	// -- Vanilla item shuffle state --
	protected bool m_grenadeShuffle = false;
	protected string m_grenadeMode = "none";     // "grouped" or "individual"
	protected dictionary m_unlockedVanillaGrenades;

	protected bool m_vestShuffle = false;
	protected string m_vestMode = "none";
	protected dictionary m_unlockedVanillaVests;

	protected bool m_costumeShuffle = false;
	protected string m_costumeMode = "none";
	protected dictionary m_unlockedVanillaCostumes;

	// -- Pending traps --
	protected array<int> m_pendingTrapIds;
	protected array<string> m_pendingTrapKeys;

	// -- Trap timers --
	protected bool m_radioJammerActive = false;
	protected float m_radioJammerTimer = 0.0;

	// -- Player state (co-op: track all human players) --
	protected array<APPlayer> m_players;

	// -- Current map --
	protected string m_currentMapId = "";

	// -- Sent checks (deduplication) --
	protected dictionary m_sentChecks;

	// -- User command (overlay) dedup --
	protected int m_lastUserCmdSeq = -1;

	// -- Processed traps (deduplication) --
	protected dictionary m_processedTraps;

	// -- RP delivery tracking --
	protected int m_rpDeliveredLocal = 0;

	// -- Goal reported --
	protected bool m_goalReported = false;

	// -- Connection message deferred to RUNNING state --
	protected bool m_connectionMessageSent = false;

	// -- Per-campaign save ID (from bridge) --
	protected string m_campaignId = "";
	protected bool m_modStateLoaded = false;

	// -- Rank tracking (only send xp_reward on rank change) --
	protected int m_lastAppliedRank = -1;
	protected int m_lastAppliedXPBoost = 0;
	protected float m_xpCooldownTimer = 0.0;  // wait after sending xp_reward

	// -- Combat milestones (kill counters: total + per-map per-method) --
	protected int m_killCount = 0;
	protected dictionary m_blastKillsByMap;     // map_id → int count
	protected dictionary m_stabKillsByMap;
	protected dictionary m_roadkillsByMap;
	protected int m_blastKillsThreshold = 5;    // overridden by ap_state.xml
	protected int m_stabKillsThreshold = 5;
	protected int m_roadkillsThreshold = 5;

	// ============================================================
	//  CONSTRUCTOR
	// ============================================================
	APTracker(Metagame@ metagame) {
		@m_metagame = @metagame;
		initAPData();
		// Opt-in to character_kill events (vanilla pattern: heal_on_kill.as, kill_commander.as)
		m_metagame.getComms().send(
			"<command class='set_metagame_event' name='character_kill' enabled='1' />");
		// loadModState() deferred until campaign_id is known from ap_state.xml
		_log("[AP] APTracker created");
	}

	void setMapRotator(APMapRotatorCampaign@ rotator) {
		@m_mapRotator = @rotator;
	}

	bool isMapUnlocked(string mapId) {
		if (mapId == STARTING_MAP_ID) return true;
		return m_unlockedMaps.exists(mapId);
	}

	// ============================================================
	//  LIFECYCLE
	// ============================================================
	bool hasStarted() const { return true; }
	bool hasEnded() const { return false; }

	void onAdd() {
		_log("[AP] APTracker registered");
	}

	// ============================================================
	//  MAIN UPDATE LOOP
	// ============================================================
	void update(float time) {
		switch (m_state) {
			case AP_DISCONNECTED:
				updateDisconnected(time);
				break;
			case AP_WAITING:
				updateWaiting(time);
				break;
			case AP_RUNNING:
				updateRunning(time);
				break;
			case AP_ERROR:
				updateError(time);
				break;
		}
	}

	// ---- DISCONNECTED ----
	protected void updateDisconnected(float time) {
		m_disconnectedMsgTimer += time;
		if (m_disconnectedMsgTimer >= DISCONNECTED_MSG_INTERVAL) {
			m_disconnectedMsgTimer = 0.0;
			sendChat("Waiting for Archipelago connection...");
		}

		m_pollTimer -= time;
		if (m_pollTimer <= 0.0) {
			m_pollTimer = POLL_INTERVAL;
			if (readAPState()) {
				_log("[AP] Bridge detected, transitioning to WAITING");
				m_state = AP_WAITING;
			}
		}
	}

	// ---- WAITING ----
	protected void updateWaiting(float time) {
		if (applyAllItems()) {
			_log("[AP] Initial state applied, transitioning to RUNNING");
			m_state = AP_RUNNING;
			m_connectionMessageSent = false;
		} else {
			_log("[AP] Failed to apply initial state, transitioning to ERROR");
			m_state = AP_ERROR;
			m_errorRetryCount = 0;
			m_errorRetryTimer = ERROR_RETRY_INTERVAL;
		}
	}

	// ---- RUNNING ----
	protected void updateRunning(float time) {
		// Sync current map ID from rotator
		if (m_mapRotator !is null) {
			string newMapId = m_mapRotator.getCurrentMapId();
			if (newMapId.length() > 0 && newMapId != m_currentMapId) {
				m_currentMapId = newMapId;
				_log("[AP] Map changed to: " + newMapId + " (" + getMapNameFromId(newMapId) + ")");
				// Scan pre-owned bases on this map for immediate checks
				scanExistingBases();
			}
		}

		m_playerScanTimer -= time;
		if (!hasAnyPlayer() || m_playerScanTimer <= 0.0) {
			findAllPlayers();
			m_playerScanTimer = PLAYER_SCAN_INTERVAL;
		}

		// Send connection message once at least one player is found
		if (!m_connectionMessageSent && hasAnyPlayer()) {
			m_connectionMessageSent = true;
			sendChat("Connected to Archipelago as " + m_slotName);
			_log("[AP] Connection message sent for slot: " + m_slotName);
		}

		// XP cooldown timer
		if (m_xpCooldownTimer > 0.0) {
			m_xpCooldownTimer -= time;
		}

		m_rankSyncTimer -= time;
		if (m_rankSyncTimer <= 0.0) {
			m_rankSyncTimer = RANK_SYNC_INTERVAL;
			applyRank();
		}

		// Poll bridge state
		m_pollTimer -= time;
		if (m_pollTimer <= 0.0) {
			m_pollTimer = POLL_INTERVAL;
			if (!pollAndApplyDelta()) {
				_log("[AP] Poll failed, transitioning to ERROR");
				m_state = AP_ERROR;
				m_errorRetryCount = 0;
				m_errorRetryTimer = ERROR_RETRY_INTERVAL;
			}
		}

		// Poll overlay user commands (fast cadence, decoupled from AP state)
		m_userCmdTimer -= time;
		if (m_userCmdTimer <= 0.0) {
			m_userCmdTimer = USER_CMD_INTERVAL;
			processUserCommand();
		}

		// Trap timers
		updateTrapTimers(time);

		// RP delivery
		updateRPDelivery(time);

		// Goal check
		checkGoal();

		// Periodic save
		m_saveTimer -= time;
		if (m_saveTimer <= 0.0) {
			m_saveTimer = SAVE_INTERVAL;
			saveModState();
		}
	}

	// ---- ERROR ----
	protected void updateError(float time) {
		m_errorRetryTimer -= time;
		if (m_errorRetryTimer <= 0.0) {
			m_errorRetryCount++;
			if (m_errorRetryCount > MAX_ERROR_RETRIES) {
				_log("[AP] Max retries exceeded, back to DISCONNECTED");
				sendChat("AP connection lost (max retries). Retrying...");
				m_state = AP_DISCONNECTED;
				m_lastVersion = -1;
			} else {
				_log("[AP] Retry " + m_errorRetryCount + "/" + MAX_ERROR_RETRIES);
				if (readAPState()) {
					m_state = AP_RUNNING;
					_log("[AP] Retry succeeded, back to RUNNING");
				} else {
					m_errorRetryTimer = ERROR_RETRY_INTERVAL;
				}
			}
		}
	}

	// ============================================================
	//  XML READING — ap_state.xml
	// ============================================================
	protected bool readAPState() {
		XmlElement@ query = XmlElement(
			makeQuery(m_metagame, array<dictionary> = {
				dictionary = {
					{"TagName", "data"},
					{"class", "saved_data"},
					{"filename", "ap_state.xml"},
					{"location", "app_data"}
				}
			})
		);

		const XmlElement@ doc = m_metagame.getComms().query(query);
		if (doc is null) return false;

		const XmlElement@ root = doc.getFirstChild();
		if (root is null) return false;

		// <ap_state connected="1" version="42" slot_name="Player1" />
		const XmlElement@ apState = root.getFirstElementByTagName("ap_state");
		if (apState is null) return false;

		int connected = apState.getIntAttribute("connected");
		if (connected == 0) {
			if (m_state == AP_RUNNING) {
				sendChat("AP bridge disconnected.");
				m_state = AP_DISCONNECTED;
				m_lastVersion = -1;
			}
			return false;
		}

		int version = apState.getIntAttribute("version");
		if (version == m_lastVersion) {
			m_dataChanged = false;
			return true;  // no changes
		}
		m_lastVersion = version;
		m_dataChanged = true;
		m_slotName = apState.getStringAttribute("slot_name");
		m_campaignId = apState.getStringAttribute("campaign_id");
		m_trapSeverity = apState.getIntAttribute("trap_severity");

		// Load per-campaign mod state once campaign_id is known
		if (!m_modStateLoaded && m_campaignId.length() > 0) {
			loadModState();
			m_modStateLoaded = true;
		}

		// <rank level="3" />
		const XmlElement@ rankElem = root.getFirstElementByTagName("rank");
		if (rankElem !is null) {
			m_apRankLevel = rankElem.getIntAttribute("level");
		}

		// <maps starting="map2">
		const XmlElement@ mapsElem = root.getFirstElementByTagName("maps");
		if (mapsElem !is null) {
			string startingMap = mapsElem.getStringAttribute("starting");
			if (startingMap.length() > 0) {
				STARTING_MAP_ID = startingMap;
			}
			m_unlockedMaps = dictionary();
			array<const XmlElement@>@ mapList = mapsElem.getElementsByTagName("map");
			for (uint i = 0; i < mapList.size(); i++) {
				if (mapList[i].getIntAttribute("unlocked") == 1) {
					m_unlockedMaps.set(mapList[i].getStringAttribute("key"), true);
				}
			}
		}
		m_unlockedMaps.set(STARTING_MAP_ID, true);

		// <weapons shuffle="1" mode="categories">
		const XmlElement@ weaponsElem = root.getFirstElementByTagName("weapons");
		if (weaponsElem !is null) {
			m_weaponShuffle = (weaponsElem.getIntAttribute("shuffle") == 1);
			m_weaponMode = weaponsElem.getStringAttribute("mode");
			m_unlockedWeaponKeys = dictionary();

			if (m_weaponMode == "categories") {
				array<const XmlElement@>@ cats = weaponsElem.getElementsByTagName("category");
				for (uint i = 0; i < cats.size(); i++) {
					if (cats[i].getIntAttribute("unlocked") == 1) {
						m_unlockedWeaponKeys.set(cats[i].getStringAttribute("key"), true);
					}
				}
			} else {
				array<const XmlElement@>@ weps = weaponsElem.getElementsByTagName("weapon");
				for (uint i = 0; i < weps.size(); i++) {
					if (weps[i].getIntAttribute("unlocked") == 1) {
						m_unlockedWeaponKeys.set(weps[i].getStringAttribute("key"), true);
					}
				}
			}
		}

		// <radio shuffle="1" master_unlocked="0">
		const XmlElement@ radioElem = root.getFirstElementByTagName("radio");
		if (radioElem !is null) {
			m_radioShuffle = (radioElem.getIntAttribute("shuffle") == 1);
			m_radioMasterUnlocked = (radioElem.getIntAttribute("master_unlocked") == 1);
			m_unlockedCallFiles = dictionary();
			array<const XmlElement@>@ calls = radioElem.getElementsByTagName("call");
			for (uint i = 0; i < calls.size(); i++) {
				if (calls[i].getIntAttribute("unlocked") == 1) {
					m_unlockedCallFiles.set(calls[i].getStringAttribute("key"), true);
				}
			}
		}

		// <equipment>
		const XmlElement@ equipElem = root.getFirstElementByTagName("equipment");
		if (equipElem !is null) {
			m_unlockedEquipFiles = dictionary();
			array<const XmlElement@>@ items = equipElem.getElementsByTagName("item");
			for (uint i = 0; i < items.size(); i++) {
				if (items[i].getIntAttribute("unlocked") == 1) {
					m_unlockedEquipFiles.set(items[i].getStringAttribute("key"), true);
				}
			}
		}

		// <throwables>
		const XmlElement@ throwElem = root.getFirstElementByTagName("throwables");
		if (throwElem !is null) {
			m_unlockedThrowFiles = dictionary();
			array<const XmlElement@>@ items = throwElem.getElementsByTagName("item");
			for (uint i = 0; i < items.size(); i++) {
				if (items[i].getIntAttribute("unlocked") == 1) {
					m_unlockedThrowFiles.set(items[i].getStringAttribute("key"), true);
				}
			}
		}

		// <vanilla_grenades shuffle="1" mode="grouped">
		const XmlElement@ vgElem = root.getFirstElementByTagName("vanilla_grenades");
		if (vgElem !is null) {
			m_grenadeShuffle = (vgElem.getIntAttribute("shuffle") == 1);
			m_grenadeMode = vgElem.getStringAttribute("mode");
			m_unlockedVanillaGrenades = dictionary();
			if (m_grenadeMode == "grouped") {
				array<const XmlElement@>@ groups = vgElem.getElementsByTagName("group");
				for (uint i = 0; i < groups.size(); i++) {
					if (groups[i].getIntAttribute("unlocked") == 1) {
						m_unlockedVanillaGrenades.set(groups[i].getStringAttribute("key"), true);
					}
				}
			} else {
				array<const XmlElement@>@ items = vgElem.getElementsByTagName("item");
				for (uint i = 0; i < items.size(); i++) {
					if (items[i].getIntAttribute("unlocked") == 1) {
						m_unlockedVanillaGrenades.set(items[i].getStringAttribute("key"), true);
					}
				}
			}
		}

		// <vanilla_vests shuffle="1" mode="grouped">
		const XmlElement@ vvElem = root.getFirstElementByTagName("vanilla_vests");
		if (vvElem !is null) {
			m_vestShuffle = (vvElem.getIntAttribute("shuffle") == 1);
			m_vestMode = vvElem.getStringAttribute("mode");
			m_unlockedVanillaVests = dictionary();
			if (m_vestMode == "grouped") {
				array<const XmlElement@>@ groups = vvElem.getElementsByTagName("group");
				for (uint i = 0; i < groups.size(); i++) {
					if (groups[i].getIntAttribute("unlocked") == 1) {
						m_unlockedVanillaVests.set(groups[i].getStringAttribute("key"), true);
					}
				}
			} else {
				array<const XmlElement@>@ items = vvElem.getElementsByTagName("item");
				for (uint i = 0; i < items.size(); i++) {
					if (items[i].getIntAttribute("unlocked") == 1) {
						m_unlockedVanillaVests.set(items[i].getStringAttribute("key"), true);
					}
				}
			}
		}

		// <vanilla_costumes shuffle="1" mode="grouped">
		const XmlElement@ vcElem = root.getFirstElementByTagName("vanilla_costumes");
		if (vcElem !is null) {
			m_costumeShuffle = (vcElem.getIntAttribute("shuffle") == 1);
			m_costumeMode = vcElem.getStringAttribute("mode");
			m_unlockedVanillaCostumes = dictionary();
			if (m_costumeMode == "grouped") {
				array<const XmlElement@>@ groups = vcElem.getElementsByTagName("group");
				for (uint i = 0; i < groups.size(); i++) {
					if (groups[i].getIntAttribute("unlocked") == 1) {
						m_unlockedVanillaCostumes.set(groups[i].getStringAttribute("key"), true);
					}
				}
			} else {
				array<const XmlElement@>@ items = vcElem.getElementsByTagName("item");
				for (uint i = 0; i < items.size(); i++) {
					if (items[i].getIntAttribute("unlocked") == 1) {
						m_unlockedVanillaCostumes.set(items[i].getStringAttribute("key"), true);
					}
				}
			}
		}

		// <resources rp_total="500" rp_delivered="0" xp_boost="0" rare_vouchers="0" pending_heals="0" />
		const XmlElement@ resElem = root.getFirstElementByTagName("resources");
		if (resElem !is null) {
			m_rpTotal = resElem.getIntAttribute("rp_total");
			m_xpBoost = resElem.getIntAttribute("xp_boost");
			m_rareVouchers = resElem.getIntAttribute("rare_vouchers");
			m_pendingHeals = resElem.getIntAttribute("pending_heals");
			// rp_delivered from bridge is informational; we track locally
		}

		// <traps>
		const XmlElement@ trapsElem = root.getFirstElementByTagName("traps");
		m_pendingTrapIds.resize(0);
		m_pendingTrapKeys.resize(0);
		if (trapsElem !is null) {
			array<const XmlElement@>@ traps = trapsElem.getElementsByTagName("trap");
			for (uint i = 0; i < traps.size(); i++) {
				int trapId = traps[i].getIntAttribute("id");
				string trapKey = traps[i].getStringAttribute("key");
				m_pendingTrapIds.insertLast(trapId);
				m_pendingTrapKeys.insertLast(trapKey);
			}
		}

		// <death_link enabled="0" pending="0" mode="kill" />
		const XmlElement@ dlElem = root.getFirstElementByTagName("death_link");
		if (dlElem !is null) {
			m_deathLinkEnabled = (dlElem.getIntAttribute("enabled") == 1);
			bool xmlPending = (dlElem.getIntAttribute("pending") == 1);
			if (!xmlPending) m_deathLinkAcked = false;  // bridge cleared → ready for next
			m_deathLinkPending = (xmlPending && !m_deathLinkAcked);
			m_deathLinkMode = dlElem.getStringAttribute("mode");
			if (m_deathLinkMode == "") m_deathLinkMode = "kill";
		}

		// <combat blast_per_map="5" stab_per_map="5" roadkill_per_map="5" />
		const XmlElement@ combatElem = root.getFirstElementByTagName("combat");
		if (combatElem !is null) {
			int v = combatElem.getIntAttribute("blast_per_map");
			if (v > 0) m_blastKillsThreshold = v;
			v = combatElem.getIntAttribute("stab_per_map");
			if (v > 0) m_stabKillsThreshold = v;
			v = combatElem.getIntAttribute("roadkill_per_map");
			if (v > 0) m_roadkillsThreshold = v;
		}

		// <rp_shop enabled="0" cost="1000" per_map="3" />
		const XmlElement@ shopElem = root.getFirstElementByTagName("rp_shop");
		if (shopElem !is null) {
			m_rpShopEnabled = (shopElem.getIntAttribute("enabled") == 1);
			m_rpShopCost = shopElem.getIntAttribute("cost");
			m_rpShopPerMap = shopElem.getIntAttribute("per_map");
		}

		// <goal complete="0" />
		const XmlElement@ goalElem = root.getFirstElementByTagName("goal");
		if (goalElem !is null) {
			m_goalComplete = (goalElem.getIntAttribute("complete") == 1);
		}

		// <notifications>
		m_notifications.resize(0);
		const XmlElement@ notifElem = root.getFirstElementByTagName("notifications");
		if (notifElem !is null) {
			array<const XmlElement@>@ nList = notifElem.getElementsByTagName("n");
			for (uint i = 0; i < nList.size(); i++) {
				m_notifications.insertLast(nList[i].getStringAttribute("text"));
			}
		}

		return true;
	}

	// ============================================================
	//  POLL + APPLY DELTA
	// ============================================================
	protected bool pollAndApplyDelta() {
		if (!readAPState()) return false;
		if (m_dataChanged) {
			bool ok = applyAllItems();
			displayNotifications();
			return ok;
		}
		return true;
	}

	// ============================================================
	//  APPLY ALL ITEMS
	// ============================================================
	protected bool applyAllItems() {
		applyRank();
		applyXPBoost();
		applyHeals();
		applyVouchers();
		applyAllFactionResources();
		syncMapUnlocks();
		processTraps();
		processDeathLink();
		return true;
	}

	// Read ap_user_command.xml written by the Tk overlay and dispatch
	// to the existing cmd*() methods. Dedup via the seq counter so we
	// don't replay the same command across multiple polls.
	protected void processUserCommand() {
		XmlElement@ query = XmlElement(
			makeQuery(m_metagame, array<dictionary> = {
				dictionary = {
					{"TagName", "data"},
					{"class", "saved_data"},
					{"filename", "ap_user_command.xml"},
					{"location", "app_data"}
				}
			})
		);
		const XmlElement@ doc = m_metagame.getComms().query(query);
		if (doc is null) return;

		const XmlElement@ root = doc.getFirstChild();
		if (root is null) return;
		const XmlElement@ cmd = root.getFirstElementByTagName("user_command");
		if (cmd is null) return;

		int seq = cmd.getIntAttribute("seq");
		if (seq == m_lastUserCmdSeq) return;  // already processed
		m_lastUserCmdSeq = seq;

		string cmdType = cmd.getStringAttribute("type");
		int senderPid = m_players.size() > 0 ? m_players[0].playerId : -1;

		if (cmdType == "buy") {
			cmdBuy(senderPid);
		} else if (cmdType == "goto") {
			string mapId = cmd.getStringAttribute("map");
			if (mapId.length() > 0) {
				cmdGotoMapId(mapId);
			}
		} else {
			_log("[AP] processUserCommand: unknown type '" + cmdType + "'");
		}
	}

	// Push current map unlock state to the map rotator.
	protected void syncMapUnlocks() {
		if (m_mapRotator !is null) {
			m_mapRotator.updateMapUnlockStatus(m_unlockedMaps);
		}
	}

	// ============================================================
	//  ITEM APPLICATION
	// ============================================================

	// ---- Rank / XP ----
	protected int _effectiveRankLevel() {
		int rankLevel = m_apRankLevel;
		if (rankLevel >= int(RANK_XP_THRESHOLDS.size())) {
			rankLevel = int(RANK_XP_THRESHOLDS.size()) - 1;
		}
		return rankLevel;
	}

	protected void applyRankToPlayer(uint idx) {
		if (idx >= m_players.size()) return;
		if (m_apRankLevel < 0) return;
		if (m_players[idx].characterId < 0) return;

		int rankLevel = _effectiveRankLevel();
		float targetXp = RANK_XP_THRESHOLDS[rankLevel];

		const XmlElement@ charInfo = getCharacterInfo(m_metagame, m_players[idx].characterId);
		if (charInfo is null) return;
		float currentXp = charInfo.getFloatAttribute("xp");

		float delta = targetXp - currentXp;
		if (delta > 0.005) {
			string cmd = "<command class='xp_reward' character_id='" +
				m_players[idx].characterId + "' reward='" + delta + "' />";
			m_metagame.getComms().send(cmd);
			_log("[AP] XP for " + m_players[idx].name + ": current=" + currentXp +
				" target=" + targetXp + " delta=+" + delta + " (rank " + rankLevel + ")");
		} else if (delta < -0.005) {
			string cmd = "<command class='xp_reward' character_id='" +
				m_players[idx].characterId + "' reward='" + delta + "' />";
			m_metagame.getComms().send(cmd);
			_log("[AP] XP for " + m_players[idx].name + ": current=" + currentXp +
				" target=" + targetXp + " delta=" + delta + " (rank " + rankLevel + ", forced down)");
		}
	}

	protected void applyRank() {
		if (!hasAnyPlayer()) return;
		if (m_apRankLevel < 0) return;

		// Cooldown: wait for previous xp_reward to be reflected in getCharacterInfo
		if (m_xpCooldownTimer > 0.0) return;

		for (uint i = 0; i < m_players.size(); i++) {
			applyRankToPlayer(i);
		}
		m_xpCooldownTimer = 5.0;
		m_lastAppliedRank = _effectiveRankLevel();
	}

	// ---- XP Boost (one-shot per new boost received) ----

	protected void applyXPBoostToPlayer(uint idx) {
		if (idx >= m_players.size() || m_xpBoost <= 0) return;
		if (m_players[idx].characterId < 0) return;

		float xpToSend = float(m_xpBoost) * 0.01;
		string cmd = "<command class='xp_reward' character_id='" +
			m_players[idx].characterId + "' reward='" + xpToSend + "' />";
		m_metagame.getComms().send(cmd);
		_log("[AP] XP boost (total " + m_xpBoost + ") applied to " + m_players[idx].name);
	}

	protected void applyXPBoost() {
		if (!hasAnyPlayer() || m_xpBoost <= 0) return;
		if (m_xpBoost == m_lastAppliedXPBoost) return;

		int boostDelta = m_xpBoost - m_lastAppliedXPBoost;
		if (boostDelta > 0) {
			float xpToSend = float(boostDelta) * 0.01;
			for (uint i = 0; i < m_players.size(); i++) {
				if (m_players[i].characterId < 0) continue;
				string cmd = "<command class='xp_reward' character_id='" +
					m_players[i].characterId + "' reward='" + xpToSend + "' />";
				m_metagame.getComms().send(cmd);
			}
			_log("[AP] XP boost +" + boostDelta + " sent to " + m_players.size() + " players");
		}
		m_lastAppliedXPBoost = m_xpBoost;
	}

	// ---- Medikit Pack heals ----
	protected void applyHeals() {
		if (!hasAnyPlayer()) return;
		while (m_pendingHeals > m_healsDelivered) {
			m_healsDelivered++;
			for (uint i = 0; i < m_players.size(); i++) {
				if (m_players[i].characterId < 0) continue;
				string cmd = "<command class='update_character' character_id='" +
					m_players[i].characterId + "' health='1.0' />";
				m_metagame.getComms().send(cmd);
			}
			sendChat("Medikit Pack: all players healed!");
			_log("[AP] Heal #" + m_healsDelivered + " applied to " + m_players.size() + " players");
		}
	}

	// ---- Rare Weapon Voucher ----
	protected void applyVouchers() {
		// Process new vouchers
		while (m_rareVouchers > m_vouchersRedeemed) {
			m_vouchersRedeemed++;

			// Build list of available rare weapons not yet unlocked by voucher
			array<string> available;
			for (uint i = 0; i < RARE_WEAPON_FILES.size(); i++) {
				if (!m_voucherUnlockedFiles.exists(RARE_WEAPON_FILES[i])) {
					available.insertLast(RARE_WEAPON_FILES[i]);
				}
			}

			if (available.size() > 0) {
				int idx = rand(0, int(available.size()) - 1);
				string file = available[idx];
				m_voucherUnlockedFiles.set(file, true);
				sendChat("Rare Weapon Voucher: unlocked " + file);
				_log("[AP] Voucher #" + m_vouchersRedeemed + " -> " + file);
			} else {
				// All rare weapons unlocked — give RP bonus
				m_voucherBonusRP += 500;
				sendChat("All rare weapons unlocked! +500 RP bonus");
				_log("[AP] Voucher #" + m_vouchersRedeemed + " -> +500 RP (all rare unlocked)");
			}
		}

		// Voucher weapons are applied via applyAllFactionResources()
	}

	// ---- All faction resources in ONE command ----
	// Consolidates weapons, calls, equipment, throwables, grenades, vests, costumes
	// into a single faction_resources command to avoid per-type overwrites.
	protected void applyAllFactionResources() {
		// Use individual commands per item like vanilla resource_unlocker does.
		// Sending one massive command doesn't work reliably.
		_log("[AP] applyAllFactionResources: weaponShuffle=" + m_weaponShuffle + " mode=" + m_weaponMode + " unlockedKeys=" + m_unlockedWeaponKeys.getSize());

		// -- Weapons --
		if (m_weaponShuffle) {
			if (m_weaponMode == "categories") {
				for (uint c = 0; c < ALL_WEAPON_CATEGORIES.size(); c++) {
					string catKey = ALL_WEAPON_CATEGORIES[c];
					bool unlocked = m_unlockedWeaponKeys.exists(catKey);
					array<string> files;
					WEAPON_CATEGORY_FILES.get(catKey, files);
					for (uint w = 0; w < files.size(); w++) {
						bool enabled = unlocked || m_voucherUnlockedFiles.exists(files[w]);
						sendFactionResource("weapon", files[w], enabled);
					}
				}
			} else {
				for (uint w = 0; w < ALL_WEAPON_FILES.size(); w++) {
					bool unlocked = m_unlockedWeaponKeys.exists(ALL_WEAPON_FILES[w]) ||
					                m_voucherUnlockedFiles.exists(ALL_WEAPON_FILES[w]);
					sendFactionResource("weapon", ALL_WEAPON_FILES[w], unlocked);
				}
			}
		} else if (m_voucherUnlockedFiles.getKeys().size() > 0) {
			array<string> keys = m_voucherUnlockedFiles.getKeys();
			for (uint i = 0; i < keys.size(); i++) {
				sendFactionResource("weapon", keys[i], true);
			}
		}

		// -- Radio calls --
		if (m_radioShuffle) {
			for (uint i = 0; i < ALL_CALL_FILES.size(); i++) {
				bool unlocked = !m_radioJammerActive && m_radioMasterUnlocked &&
				                m_unlockedCallFiles.exists(ALL_CALL_FILES[i]);
				sendFactionResource("call", ALL_CALL_FILES[i], unlocked);
			}
		} else if (m_radioJammerActive) {
			for (uint i = 0; i < ALL_CALL_FILES.size(); i++) {
				sendFactionResource("call", ALL_CALL_FILES[i], false);
			}
		}

		// -- Equipment (mixed types: weapon, carry_item) --
		for (uint i = 0; i < ALL_EQUIPMENT_FILES.size(); i++) {
			string file = ALL_EQUIPMENT_FILES[i];
			bool unlocked = m_unlockedEquipFiles.exists(file);
			string type;
			EQUIPMENT_FILE_TO_TYPE.get(file, type);
			sendFactionResource(type, file, unlocked);
		}

		// -- Throwables (mixed types: projectile, weapon) --
		for (uint i = 0; i < ALL_THROWABLE_FILES.size(); i++) {
			string file = ALL_THROWABLE_FILES[i];
			bool unlocked = m_unlockedThrowFiles.exists(file);
			string type;
			THROWABLE_FILE_TO_TYPE.get(file, type);
			sendFactionResource(type, file, unlocked);
		}

		// -- Vanilla grenades --
		if (m_grenadeShuffle) {
			if (m_grenadeMode == "grouped") {
				bool unlocked = m_unlockedVanillaGrenades.exists("all");
				for (uint i = 0; i < VANILLA_GRENADE_FILES.size(); i++) {
					sendFactionResource("projectile", VANILLA_GRENADE_FILES[i], unlocked);
				}
			} else {
				for (uint i = 0; i < VANILLA_GRENADE_FILES.size(); i++) {
					bool unlocked = m_unlockedVanillaGrenades.exists(VANILLA_GRENADE_FILES[i]);
					sendFactionResource("projectile", VANILLA_GRENADE_FILES[i], unlocked);
				}
			}
		}

		// -- Vanilla vests --
		if (m_vestShuffle) {
			if (m_vestMode == "grouped") {
				bool unlocked = m_unlockedVanillaVests.exists("all");
				for (uint i = 0; i < VANILLA_VEST_FILES.size(); i++) {
					sendFactionResource("carry_item", VANILLA_VEST_FILES[i], unlocked);
				}
			} else {
				for (uint i = 0; i < VANILLA_VEST_FILES.size(); i++) {
					bool unlocked = m_unlockedVanillaVests.exists(VANILLA_VEST_FILES[i]);
					sendFactionResource("carry_item", VANILLA_VEST_FILES[i], unlocked);
				}
			}
		}

		// -- Vanilla costumes --
		if (m_costumeShuffle) {
			if (m_costumeMode == "grouped") {
				bool unlocked = m_unlockedVanillaCostumes.exists("all");
				for (uint i = 0; i < VANILLA_COSTUME_FILES.size(); i++) {
					sendFactionResource("carry_item", VANILLA_COSTUME_FILES[i], unlocked);
				}
			} else {
				for (uint i = 0; i < VANILLA_COSTUME_FILES.size(); i++) {
					bool unlocked = m_unlockedVanillaCostumes.exists(VANILLA_COSTUME_FILES[i]);
					sendFactionResource("carry_item", VANILLA_COSTUME_FILES[i], unlocked);
				}
			}
		}
	}

	protected void sendFactionResource(string type, string key, bool enabled) {
		XmlElement command("command");
		command.setStringAttribute("class", "faction_resources");
		command.setStringAttribute("soldier_group_name", "default");
		command.setIntAttribute("faction_id", 0);
		XmlElement item(type);
		item.setStringAttribute("key", key);
		item.setBoolAttribute("enabled", enabled);
		command.appendChild(item);
		if (enabled) {
			_log("[AP] faction_resource: " + type + " " + key + " enabled=" + (enabled ? "1" : "0"));
		}
		m_metagame.getComms().send(command);
	}

	// ---- RP delivery (gradual, to all players) ----
	protected void updateRPDelivery(float time) {
		if (!hasAnyPlayer()) return;
		int rpOwed = (m_rpTotal + m_voucherBonusRP) - m_rpDeliveredLocal;
		if (rpOwed <= 0) return;

		m_rpDeliveryTimer -= time;
		if (m_rpDeliveryTimer <= 0.0) {
			m_rpDeliveryTimer = RP_DELIVERY_INTERVAL;

			int toDeliver = rpOwed;
			if (toDeliver > RP_PER_DELIVERY) toDeliver = RP_PER_DELIVERY;

			for (uint i = 0; i < m_players.size(); i++) {
				if (m_players[i].characterId < 0) continue;
				string cmd = "<command class='rp_reward' character_id='" +
					m_players[i].characterId + "' reward='" + toDeliver + "' />";
				m_metagame.getComms().send(cmd);
			}
			m_rpDeliveredLocal += toDeliver;
		}
	}

	// ============================================================
	//  LOCATION DETECTION
	// ============================================================

	// ---- Scan pre-owned bases on map arrival ----
	protected void scanExistingBases() {
		if (m_state != AP_RUNNING) return;
		string mapName = getMapNameFromId(m_currentMapId);
		array<const XmlElement@> bases = getBases(m_metagame);

		for (uint i = 0; i < bases.size(); i++) {
			if (bases[i].getIntAttribute("owner_id") == 0) {
				string baseName = bases[i].getStringAttribute("name");
				if (baseName.length() > 0) {
					reportCheck("Captured " + baseName + " (" + mapName + ")");
				}
			}
		}

		checkBaseCaptures(mapName);
		_log("[AP] Scanned existing bases on " + mapName);
	}

	// ---- Base capture / conquest ----
	protected void handleBaseOwnerChangeEvent(const XmlElement@ event) {
		if (m_state != AP_RUNNING) return;
		if (event is null) return;

		int newOwner = event.getIntAttribute("owner_id");
		if (newOwner != 0) return;  // only care about player faction captures

		int baseId = event.getIntAttribute("base_id");
		string mapName = getMapNameFromId(m_currentMapId);

		// Resolve base name
		const XmlElement@ baseInfo = getBase(m_metagame, baseId);
		string baseName = "";
		if (baseInfo !is null) {
			baseName = baseInfo.getStringAttribute("name");
		}

		// Individual base capture
		if (baseName.length() > 0) {
			reportCheck("Captured " + baseName + " (" + mapName + ")");
		}

		// Progressive capture count + map conquest
		checkBaseCaptures(mapName);
	}

	// ---- Combat milestones (kills) ----
	protected void handleCharacterKillEvent(const XmlElement@ event) {
		if (m_state != AP_RUNNING || event is null) return;

		const XmlElement@ killer = event.getFirstElementByTagName("killer");
		const XmlElement@ target = event.getFirstElementByTagName("target");
		if (killer is null || target is null) return;

		int killerPid = killer.getIntAttribute("player_id");
		int targetFaction = target.getIntAttribute("faction_id");

		// Only count: a tracked human killed an enemy (skip AI vs AI, skip friendly fire)
		if (killerPid < 0 || !isPlayerTracked(killerPid)) return;
		if (targetFaction == 0) return;

		// Cumulative kill milestones (shared across all tracked players)
		m_killCount++;
		array<int> milestones = {1, 10, 25, 50, 100, 200, 500, 1000};
		for (uint i = 0; i < milestones.size(); i++) {
			if (m_killCount == milestones[i]) {
				string suffix = (milestones[i] == 1) ? " enemy" : " enemies";
				reportCheck("Killed " + milestones[i] + suffix);
			}
		}

		// Per-map per-method threshold checks
		if (m_currentMapId.length() == 0) return;
		string method = event.getStringAttribute("method_hint");
		string mapName = getMapNameFromId(m_currentMapId);
		if (mapName.length() == 0) return;

		if (method == "blast") {
			int n = bumpKillCounter(m_blastKillsByMap, m_currentMapId);
			if (n >= m_blastKillsThreshold) reportCheck("Blast kill on " + mapName);
		} else if (method == "stab") {
			int n = bumpKillCounter(m_stabKillsByMap, m_currentMapId);
			if (n >= m_stabKillsThreshold) reportCheck("Stab kill on " + mapName);
		} else if (method == "drive_over") {
			int n = bumpKillCounter(m_roadkillsByMap, m_currentMapId);
			if (n >= m_roadkillsThreshold) reportCheck("Roadkill on " + mapName);
		}
	}

	protected int bumpKillCounter(dictionary@ d, string key) {
		int n = 0;
		d.get(key, n);
		n++;
		d.set(key, n);
		return n;
	}

	protected string serializeKillCounter(string tag, dictionary@ d) {
		string buf = "<" + tag + ">";
		array<string> keys = d.getKeys();
		for (uint i = 0; i < keys.size(); i++) {
			int n = 0;
			d.get(keys[i], n);
			buf += "<map id='" + escapeXml(keys[i]) + "' count='" + n + "' />";
		}
		buf += "</" + tag + ">";
		return buf;
	}

	protected void checkBaseCaptures(string mapName) {
		array<const XmlElement@> bases = getBases(m_metagame);
		int ownedCount = 0;
		int totalCount = int(bases.size());

		for (uint i = 0; i < bases.size(); i++) {
			if (bases[i].getIntAttribute("owner_id") == 0) {
				ownedCount++;
			}
		}

		// Progressive milestones
		for (int n = 1; n <= ownedCount; n++) {
			reportCheck("Captured " + n + " bases on " + mapName);
		}

		// Full conquest
		if (ownedCount >= totalCount && totalCount > 0) {
			bool isFinal = isFinalMission(m_currentMapId);
			string prefix = isFinal ? "Completed " : "Conquered ";
			reportCheck(prefix + mapName);

			// Side mission auto-completes with conquest (V1)
			if (!isFinal) {
				reportCheck("Side Objective (" + mapName + ")");
			}
		}
	}

	// ---- Goal ----
	protected void checkGoal() {
		if (m_goalComplete && !m_goalReported) {
			m_goalReported = true;
			_log("[AP_GOAL] complete");
			sendChat("GOAL COMPLETE! Congratulations!");
			saveModState();
		}
	}

	// ---- Report check (with deduplication) ----
	protected void reportCheck(string locationName) {
		if (m_sentChecks.exists(locationName)) return;
		m_sentChecks.set(locationName, true);
		_log("[AP_CHECK] " + locationName);
		sendChat("CHECK: " + locationName);
		saveModState();  // persist immediately
	}

	// ============================================================
	//  NOTIFICATIONS
	// ============================================================
	protected void displayNotifications() {
		for (uint i = 0; i < m_notifications.size(); i++) {
			sendChat("[AP] " + m_notifications[i]);
		}
		if (m_notifications.size() > 0) {
			_log("[AP_NOTIFY_ACK]");
			m_notifications.resize(0);
		}
	}

	// ============================================================
	//  TRAPS
	// ============================================================
	protected void processTraps() {
		for (uint i = 0; i < m_pendingTrapIds.size(); i++) {
			string idStr = "" + m_pendingTrapIds[i];
			if (m_processedTraps.exists(idStr)) continue;

			executeTrap(m_pendingTrapKeys[i]);
			m_processedTraps.set(idStr, true);
			_log("[AP_TRAP_ACK] id=" + m_pendingTrapIds[i]);
		}
	}

	protected void executeTrap(string trapKey) {
		if (trapKey == "demotion") {
			sendChat("TRAP: Demoted! Your rank has been reduced.");
			// Rank is already adjusted in ap_state.xml by bridge.
			// XP will be corrected on next applyRank() call.
		}
		else if (trapKey == "radio_jammer") {
			float dur = 90.0;
			if (m_trapSeverity == 0) dur = 30.0;
			else if (m_trapSeverity == 2) dur = 150.0;
			sendChat("TRAP: Radio Jammer! Comms disabled for " + int(dur) + " seconds.");
			m_radioJammerActive = true;
			m_radioJammerTimer = dur;
			disableAllCalls();
		}
		else if (trapKey == "friendly_fire") {
			if (m_trapSeverity == 0) {
				sendChat("TRAP: Friendly Fire Incident! All players wounded.");
				for (uint i = 0; i < m_players.size(); i++) {
					if (m_players[i].characterId < 0) continue;
					string cmd = "<command class='update_character' character_id='" +
						m_players[i].characterId + "' health='0.5' />";
					m_metagame.getComms().send(cmd);
				}
			} else {
				sendChat("TRAP: Friendly Fire Incident!");
				for (uint i = 0; i < m_players.size(); i++) {
					if (m_players[i].characterId < 0) continue;
					killCharacter(m_metagame, m_players[i].characterId);
				}
				if (m_trapSeverity == 2) {
					killNearbyFriendlies(2);
				}
			}
		}
	}

	protected void disableAllCalls() {
		for (uint i = 0; i < ALL_CALL_FILES.size(); i++) {
			sendFactionResource("call", ALL_CALL_FILES[i], false);
		}
	}

	protected void killNearbyFriendlies(int count) {
		// Kill up to 'count' nearby faction-0 AI soldiers (skip all human players)
		array<const XmlElement@> chars = getCharacters(m_metagame, 0);
		int killed = 0;
		for (uint i = 0; i < chars.size() && killed < count; i++) {
			int pid = chars[i].getIntAttribute("player_id");
			if (pid >= 0) continue;  // skip all human players

			int charId = chars[i].getIntAttribute("id");
			killCharacter(m_metagame, charId);
			killed++;
		}
		_log("[AP] Killed " + killed + " friendly AI soldiers");
	}

	protected void updateTrapTimers(float time) {
		if (m_radioJammerActive) {
			m_radioJammerTimer -= time;
			if (m_radioJammerTimer <= 0.0) {
				m_radioJammerActive = false;
				sendChat("Radio jammer expired. Comms restored.");
				applyAllFactionResources();  // re-enable unlocked calls
			}
		}
	}

	// ============================================================
	//  DEATH LINK
	// ============================================================
	protected void handlePlayerDieEvent(const XmlElement@ event) {
		if (m_state != AP_RUNNING) return;
		if (event is null) return;

		// Extract player_id from the death event target
		array<const XmlElement@>@ targets = event.getElementsByTagName("target");
		if (targets.size() == 0) return;
		int pid = targets[0].getIntAttribute("player_id");

		int idx = getPlayerIndex(pid);
		if (idx < 0) return;  // not a tracked player

		m_players[idx].alive = false;

		// Anti-loop: don't report deaths we caused via death link
		if (m_players[idx].deathLinkKillInProgress) {
			m_players[idx].deathLinkKillInProgress = false;
			return;
		}

		if (m_deathLinkEnabled) {
			_log("[AP_DEATH] " + m_players[idx].name + " died");
		}
	}

	protected void processDeathLink() {
		if (!m_deathLinkPending || !m_deathLinkEnabled) return;

		// Check if any tracked player is alive
		bool anyAlive = false;
		for (uint i = 0; i < m_players.size(); i++) {
			if (m_players[i].alive && m_players[i].characterId >= 0) {
				anyAlive = true;
				break;
			}
		}
		if (!anyAlive) return;

		if (m_deathLinkMode == "random_trap") {
			array<string> trapKeys = {"demotion", "radio_jammer", "friendly_fire"};
			string pick = trapKeys[rand(0, int(trapKeys.size()) - 1)];
			sendChat("DEATH LINK: Another player has fallen... (trap: " + pick + ")");
			executeTrap(pick);
		} else {
			sendChat("DEATH LINK: Another player has fallen...");
			for (uint i = 0; i < m_players.size(); i++) {
				if (m_players[i].alive && m_players[i].characterId >= 0) {
					m_players[i].deathLinkKillInProgress = true;
					killCharacter(m_metagame, m_players[i].characterId);
				}
			}
		}
		m_deathLinkPending = false;
		m_deathLinkAcked = true;  // don't re-fire while bridge still has pending=1
		_log("[AP_DEATHLINK_ACK]");
	}

	// ============================================================
	//  PLAYER TRACKING (co-op: all human players)
	// ============================================================

	protected bool isPlayerTracked(int playerId) {
		for (uint i = 0; i < m_players.size(); i++) {
			if (m_players[i].playerId == playerId) return true;
		}
		return false;
	}

	protected int getPlayerIndex(int playerId) {
		for (uint i = 0; i < m_players.size(); i++) {
			if (m_players[i].playerId == playerId) return int(i);
		}
		return -1;
	}

	protected bool hasAnyPlayer() {
		return m_players.size() > 0;
	}

	protected int getAnyCharacterId() {
		for (uint i = 0; i < m_players.size(); i++) {
			if (m_players[i].characterId >= 0) return m_players[i].characterId;
		}
		return -1;
	}

	// Scan all connected human players and track them.
	protected void findAllPlayers() {
		array<const XmlElement@> players = getPlayers(m_metagame);
		for (uint i = 0; i < players.size(); i++) {
			const XmlElement@ p = players[i];
			int charId = p.getIntAttribute("character_id");
			int pid = p.getIntAttribute("player_id");
			string name = p.getStringAttribute("name");
			if (charId >= 0 && !isPlayerTracked(pid)) {
				APPlayer pl;
				pl.playerId = pid;
				pl.characterId = charId;
				pl.name = name;
				pl.alive = true;
				m_players.insertLast(pl);
				uint newIdx = m_players.size() - 1;
				_log("[AP] Tracking player: " + name + " pid=" + pid + " char=" + charId);

				if (m_state == AP_RUNNING) {
					applyRankToPlayer(newIdx);
					applyXPBoostToPlayer(newIdx);
				}
			}
		}
	}

	protected void handlePlayerSpawnEvent(const XmlElement@ event) {
		if (event is null) return;
		const XmlElement@ player = event.getFirstElementByTagName("player");
		if (player is null) return;

		string name = player.getStringAttribute("name");
		int charId = player.getIntAttribute("character_id");
		int pid = player.getIntAttribute("player_id");

		int idx = getPlayerIndex(pid);
		if (idx >= 0) {
			// Existing player respawned (character_id may change)
			m_players[idx].characterId = charId;
			m_players[idx].name = name;
			m_players[idx].alive = true;
			_log("[AP] Player respawned: " + name + " char=" + charId);
		} else {
			// New player joined
			APPlayer pl;
			pl.playerId = pid;
			pl.characterId = charId;
			pl.name = name;
			pl.alive = true;
			m_players.insertLast(pl);
			uint newIdx = m_players.size() - 1;
			_log("[AP] New player joined: " + name + " pid=" + pid + " char=" + charId);

			if (m_state == AP_RUNNING) {
				applyRankToPlayer(newIdx);
				applyXPBoostToPlayer(newIdx);
			}
		}
	}

	protected void handlePlayerDisconnectEvent(const XmlElement@ event) {
		if (event is null) return;
		const XmlElement@ player = event.getFirstElementByTagName("player");
		if (player is null) return;
		int pid = player.getIntAttribute("player_id");

		int idx = getPlayerIndex(pid);
		if (idx >= 0) {
			_log("[AP] Player disconnected: " + m_players[idx].name);
			m_players.removeAt(idx);
			if (m_players.size() == 0 && m_state == AP_RUNNING) {
				_log("[AP] No players tracked — waiting for host to respawn.");
			}
		}
	}

	// ============================================================
	//  CHAT COMMANDS
	// ============================================================
	protected void handleChatEvent(const XmlElement@ event) {
		if (event is null) return;
		string message = event.getStringAttribute("message");
		if (!startsWith(message, "/")) return;

		int senderPid = event.getIntAttribute("player_id");

		if (checkCommand(message, "apstatus")) {
			cmdStatus();
		} else if (checkCommand(message, "apitems")) {
			cmdItems();
		} else if (checkCommand(message, "apmaps")) {
			cmdMaps();
		} else if (checkCommand(message, "aplocs")) {
			cmdChecks();
		} else if (checkCommand(message, "aphelp")) {
			cmdHelp();
		} else if (checkCommand(message, "apbuy")) {
			cmdBuy(senderPid);
		} else if (checkCommand(message, "apshop")) {
			cmdShop(senderPid);
		} else if (checkCommand(message, "goto")) {
			cmdGoto(message);
		}
	}

	protected void cmdStatus() {
		string stateName = "UNKNOWN";
		if (m_state == AP_DISCONNECTED) stateName = "DISCONNECTED";
		else if (m_state == AP_WAITING)  stateName = "WAITING";
		else if (m_state == AP_RUNNING)  stateName = "RUNNING";
		else if (m_state == AP_ERROR)    stateName = "ERROR";

		sendChat("Status: " + stateName);
		if (m_state == AP_RUNNING) {
			sendChat("Slot: " + m_slotName);
			string rankName = "Private";
			if (m_apRankLevel >= 0 && m_apRankLevel < int(RANK_NAMES.size())) {
				rankName = RANK_NAMES[m_apRankLevel];
			}
			sendChat("Rank: " + rankName + " (" + m_apRankLevel + ")");

			int mapCount = 0;
			array<string> mapKeys = m_unlockedMaps.getKeys();
			mapCount = int(mapKeys.size());
			sendChat("Maps: " + mapCount + "/12");

			int checkCount = int(m_sentChecks.getKeys().size());
			sendChat("Checks sent: " + checkCount);
		}
	}

	protected void cmdItems() {
		if (m_state != AP_RUNNING) {
			sendChat("Not connected to AP.");
			return;
		}

		if (m_weaponShuffle) {
			int weaponCount = int(m_unlockedWeaponKeys.getKeys().size());
			sendChat("Weapons (" + m_weaponMode + "): " + weaponCount + " unlocked");
		} else {
			sendChat("Weapons: vanilla progression");
		}

		if (m_radioShuffle) {
			int callCount = int(m_unlockedCallFiles.getKeys().size());
			string masterStr = m_radioMasterUnlocked ? "YES" : "NO";
			sendChat("Radio: master=" + masterStr + ", calls=" + callCount);
		}

		sendChat("Equipment: " + m_unlockedEquipFiles.getKeys().size() +
			" | Throwables: " + m_unlockedThrowFiles.getKeys().size());
		sendChat("Rank: " + m_apRankLevel + " | RP owed: " + ((m_rpTotal + m_voucherBonusRP) - m_rpDeliveredLocal) +
			" | Vouchers: " + m_vouchersRedeemed + "/" + m_rareVouchers);
	}

	protected void cmdGoto(string message) {
		// Parse "/goto Map Name Here" — skip command prefix
		int spacePos = message.findFirst(" ");
		if (spacePos < 0) {
			sendChat("Usage: /goto <map name>");
			return;
		}
		string mapName = message.substr(spacePos + 1);

		while (mapName.length() > 0 && mapName.substr(0, 1) == " ") {
			mapName = mapName.substr(1);
		}

		if (mapName.length() == 0) {
			sendChat("Usage: /goto <map name>");
			return;
		}

		string mapId = getMapIdFromName(mapName);
		if (mapId.length() == 0) {
			sendChat("Unknown map: " + mapName);
			sendChat("Use real names like: Moorland Trenches, Keepsake Bay, ...");
			return;
		}
		cmdGotoMapId(mapId);
	}

	protected void cmdGotoMapId(string mapId) {
		string resolvedName = getMapNameFromId(mapId);
		if (resolvedName.length() == 0) {
			sendChat("Unknown map id: " + mapId);
			return;
		}

		if (!isMapUnlocked(mapId)) {
			sendChat("Map '" + resolvedName + "' is locked. You need the key!");
			return;
		}

		if (m_mapRotator is null) {
			sendChat("Map travel not available (no map rotator).");
			_log("[AP] goto failed: m_mapRotator is null");
			return;
		}

		sendChat("Traveling to " + resolvedName + "... Stand by for extraction.");
		_log("[AP] goto: requesting change to " + mapId + " (" + resolvedName + ")");
		m_mapRotator.requestMapChange(mapId);
	}

	protected void cmdMaps() {
		sendChat("Maps:");
		for (uint i = 0; i < ALL_MAP_IDS.size(); i++) {
			string mapId = ALL_MAP_IDS[i];
			string mapName = getMapNameFromId(mapId);
			string status = isMapUnlocked(mapId) ? "[OK]" : "[LOCKED]";
			sendChat("  " + status + " " + mapName);
		}
	}

	protected void cmdChecks() {
		if (m_mapRotator is null) {
			sendChat("Map info not available.");
			return;
		}
		string mapId = m_mapRotator.getCurrentMapId();
		string mapName = getMapNameFromId(mapId);
		int sent = 0;
		array<string> allChecks = m_sentChecks.getKeys();
		for (uint i = 0; i < allChecks.size(); i++) {
			if (allChecks[i].findFirst(mapName) >= 0) {
				sent++;
			}
		}
		sendChat("Map: " + mapName + " - " + sent + " checks sent");
	}

	protected void cmdBuy(int senderPid) {
		if (m_state != AP_RUNNING) {
			sendChat("Not connected to AP.");
			return;
		}
		if (!m_rpShopEnabled) {
			sendChat("RP Shop is not enabled for this seed.");
			return;
		}
		if (m_mapRotator is null) {
			sendChat("Map info not available.");
			return;
		}

		string mapId = m_mapRotator.getCurrentMapId();
		string mapName = getMapNameFromId(mapId);

		// Get purchase count for this map
		int purchased = 0;
		if (m_rpShopPurchased.exists(mapName)) {
			m_rpShopPurchased.get(mapName, purchased);
		}

		if (purchased >= m_rpShopPerMap) {
			sendChat("No more RP Shop checks on " + mapName + " (" + purchased + "/" + m_rpShopPerMap + ").");
			return;
		}

		// Find the sender's character
		int idx = getPlayerIndex(senderPid);
		if (idx < 0 || m_players[idx].characterId < 0) {
			sendChat("Player not found.");
			return;
		}
		int charId = m_players[idx].characterId;

		const XmlElement@ charInfo = getCharacterInfo(m_metagame, charId);
		if (charInfo is null) {
			sendChat("Cannot read player info.");
			return;
		}
		int playerRP = charInfo.getIntAttribute("rp");

		if (playerRP < m_rpShopCost) {
			sendChat("Not enough RP! Need " + m_rpShopCost + ", have " + playerRP + ".");
			return;
		}

		// Deduct RP from the player who typed the command
		string cmd = "<command class='rp_reward' character_id='" +
			charId + "' reward='" + (-m_rpShopCost) + "' />";
		m_metagame.getComms().send(cmd);

		// Increment and report check (shared limit)
		purchased++;
		m_rpShopPurchased.set(mapName, purchased);
		string locName = "RP Shop " + purchased + " (" + mapName + ")";
		reportCheck(locName);

		int remaining = m_rpShopPerMap - purchased;
		sendChat(m_players[idx].name + " purchased! " + remaining + " remaining on " + mapName + ".");

		// Save immediately
		saveModState();
	}

	protected void cmdShop(int senderPid) {
		if (m_state != AP_RUNNING) {
			sendChat("Not connected to AP.");
			return;
		}
		if (!m_rpShopEnabled) {
			sendChat("RP Shop is not enabled for this seed.");
			return;
		}
		if (m_mapRotator is null) {
			sendChat("Map info not available.");
			return;
		}

		string mapId = m_mapRotator.getCurrentMapId();
		string mapName = getMapNameFromId(mapId);

		int purchased = 0;
		if (m_rpShopPurchased.exists(mapName)) {
			m_rpShopPurchased.get(mapName, purchased);
		}
		int remaining = m_rpShopPerMap - purchased;

		// Read RP of the player who typed the command
		string rpStr = "?";
		int idx = getPlayerIndex(senderPid);
		if (idx >= 0 && m_players[idx].characterId >= 0) {
			const XmlElement@ charInfo = getCharacterInfo(m_metagame, m_players[idx].characterId);
			if (charInfo !is null) {
				rpStr = "" + charInfo.getIntAttribute("rp");
			}
		}

		sendChat("RP Shop (" + mapName + "): " + remaining + "/" + m_rpShopPerMap + " remaining");
		sendChat("Cost: " + m_rpShopCost + " RP | Your RP: " + rpStr);
	}

	protected void cmdHelp() {
		sendChat("AP Commands:");
		sendChat("  /apstatus  - Connection status & progress");
		sendChat("  /apitems   - Unlocked items summary");
		sendChat("  /apmaps    - Show map unlock status");
		sendChat("  /aplocs    - Checks on current map");
		sendChat("  /apbuy     - Buy an RP Shop check");
		sendChat("  /apshop    - Show RP Shop status");
		sendChat("  /goto <map> - Fast travel to unlocked map");
		sendChat("  /aphelp    - This help");
	}

	// ============================================================
	//  PERSISTENCE — save_data / saved_data
	// ============================================================
	protected void saveModState() {
		string filename = "ap_mod_state.xml";
		if (m_campaignId.length() > 0) {
			filename = "ap_mod_state_" + m_campaignId + ".xml";
		}
		string cmd = "<command class='save_data' filename='" + filename + "' location='app_data'>";
		cmd += "<ap_mod_state>";

		// Sent checks
		cmd += "<checks>";
		array<string> checkKeys = m_sentChecks.getKeys();
		for (uint i = 0; i < checkKeys.size(); i++) {
			cmd += "<check name='" + escapeXml(checkKeys[i]) + "' />";
		}
		cmd += "</checks>";

		// Processed traps
		cmd += "<traps_processed>";
		array<string> trapKeys = m_processedTraps.getKeys();
		for (uint i = 0; i < trapKeys.size(); i++) {
			cmd += "<trap id='" + trapKeys[i] + "' />";
		}
		cmd += "</traps_processed>";

		// RP delivered
		cmd += "<rp_delivered value='" + m_rpDeliveredLocal + "' />";

		// Heals delivered
		cmd += "<heals delivered='" + m_healsDelivered + "' />";

		// Voucher state
		cmd += "<vouchers redeemed='" + m_vouchersRedeemed + "' bonus_rp='" + m_voucherBonusRP + "'>";
		array<string> voucherKeys = m_voucherUnlockedFiles.getKeys();
		for (uint i = 0; i < voucherKeys.size(); i++) {
			cmd += "<weapon file='" + escapeXml(voucherKeys[i]) + "' />";
		}
		cmd += "</vouchers>";

		// RP Shop purchases
		cmd += "<rp_shop_purchased>";
		array<string> shopKeys = m_rpShopPurchased.getKeys();
		for (uint i = 0; i < shopKeys.size(); i++) {
			int count = 0;
			m_rpShopPurchased.get(shopKeys[i], count);
			cmd += "<map name='" + escapeXml(shopKeys[i]) + "' count='" + count + "' />";
		}
		cmd += "</rp_shop_purchased>";

		// Delivery counters (briefcase/laptop)
		cmd += "<deliveries briefcases='" + g_apBriefcaseCount + "' laptops='" + g_apLaptopCount + "' />";

		// XP tracking (to avoid re-sending xp_reward on reconnect)
		cmd += "<xp_tracking last_rank='" + m_lastAppliedRank + "' last_xp_boost='" + m_lastAppliedXPBoost + "' />";

		// Combat milestones
		cmd += "<combat kill_count='" + m_killCount + "'>";
		cmd += serializeKillCounter("blast", m_blastKillsByMap);
		cmd += serializeKillCounter("stab", m_stabKillsByMap);
		cmd += serializeKillCounter("roadkill", m_roadkillsByMap);
		cmd += "</combat>";

		cmd += "</ap_mod_state>";
		cmd += "</command>";
		m_metagame.getComms().send(cmd);
	}

	protected void loadModState() {
		string filename = "ap_mod_state.xml";
		if (m_campaignId.length() > 0) {
			filename = "ap_mod_state_" + m_campaignId + ".xml";
		}
		_log("[AP] Loading mod state from: " + filename);
		XmlElement@ query = XmlElement(
			makeQuery(m_metagame, array<dictionary> = {
				dictionary = {
					{"TagName", "data"},
					{"class", "saved_data"},
					{"filename", filename},
					{"location", "app_data"}
				}
			})
		);

		const XmlElement@ doc = m_metagame.getComms().query(query);
		if (doc is null) {
			_log("[AP] No saved mod state found (first run)");
			return;
		}

		const XmlElement@ root = doc.getFirstChild();
		if (root is null) return;

		const XmlElement@ modState = root.getFirstElementByTagName("ap_mod_state");
		if (modState is null) {
			// Maybe root IS the ap_mod_state
			@modState = root;
		}

		// Restore sent checks
		const XmlElement@ checksElem = modState.getFirstElementByTagName("checks");
		if (checksElem !is null) {
			array<const XmlElement@>@ checks = checksElem.getElementsByTagName("check");
			for (uint i = 0; i < checks.size(); i++) {
				string name = checks[i].getStringAttribute("name");
				if (name.length() > 0) {
					m_sentChecks.set(name, true);
				}
			}
			_log("[AP] Restored " + checks.size() + " sent checks from save");
		}

		// Restore processed traps
		const XmlElement@ trapsElem = modState.getFirstElementByTagName("traps_processed");
		if (trapsElem !is null) {
			array<const XmlElement@>@ traps = trapsElem.getElementsByTagName("trap");
			for (uint i = 0; i < traps.size(); i++) {
				string id = traps[i].getStringAttribute("id");
				if (id.length() > 0) {
					m_processedTraps.set(id, true);
				}
			}
			_log("[AP] Restored " + traps.size() + " processed traps from save");
		}

		// Restore RP delivered
		const XmlElement@ rpElem = modState.getFirstElementByTagName("rp_delivered");
		if (rpElem !is null) {
			m_rpDeliveredLocal = rpElem.getIntAttribute("value");
			_log("[AP] Restored RP delivered: " + m_rpDeliveredLocal);
		}

		// Restore heals delivered
		const XmlElement@ healsElem = modState.getFirstElementByTagName("heals");
		if (healsElem !is null) {
			m_healsDelivered = healsElem.getIntAttribute("delivered");
			_log("[AP] Restored heals delivered: " + m_healsDelivered);
		}

		// Restore voucher state
		const XmlElement@ vouchersElem = modState.getFirstElementByTagName("vouchers");
		if (vouchersElem !is null) {
			m_vouchersRedeemed = vouchersElem.getIntAttribute("redeemed");
			m_voucherBonusRP = vouchersElem.getIntAttribute("bonus_rp");
			array<const XmlElement@>@ vWeapons = vouchersElem.getElementsByTagName("weapon");
			for (uint i = 0; i < vWeapons.size(); i++) {
				string file = vWeapons[i].getStringAttribute("file");
				if (file.length() > 0) {
					m_voucherUnlockedFiles.set(file, true);
				}
			}
			_log("[AP] Restored voucher state: " + m_vouchersRedeemed + " redeemed, " +
				m_voucherUnlockedFiles.getKeys().size() + " weapons unlocked, " +
				m_voucherBonusRP + " bonus RP");
		}

		// Restore RP Shop purchases
		const XmlElement@ rpShopElem = modState.getFirstElementByTagName("rp_shop_purchased");
		if (rpShopElem !is null) {
			array<const XmlElement@>@ shopMaps = rpShopElem.getElementsByTagName("map");
			for (uint i = 0; i < shopMaps.size(); i++) {
				string name = shopMaps[i].getStringAttribute("name");
				int count = shopMaps[i].getIntAttribute("count");
				if (name.length() > 0 && count > 0) {
					m_rpShopPurchased.set(name, count);
				}
			}
			_log("[AP] Restored RP Shop purchases: " + m_rpShopPurchased.getKeys().size() + " maps");
		}

		// Restore delivery counters
		const XmlElement@ delElem = modState.getFirstElementByTagName("deliveries");
		if (delElem !is null) {
			g_apBriefcaseCount = delElem.getIntAttribute("briefcases");
			g_apLaptopCount = delElem.getIntAttribute("laptops");
			_log("[AP] Restored delivery counters: " + g_apBriefcaseCount +
				" briefcases, " + g_apLaptopCount + " laptops");
		}

		// Restore XP tracking
		const XmlElement@ xpElem = modState.getFirstElementByTagName("xp_tracking");
		if (xpElem !is null) {
			m_lastAppliedRank = xpElem.getIntAttribute("last_rank");
			m_lastAppliedXPBoost = xpElem.getIntAttribute("last_xp_boost");
			_log("[AP] Restored XP tracking: last_rank=" + m_lastAppliedRank +
				", last_xp_boost=" + m_lastAppliedXPBoost);
		}

		// Restore combat milestones
		const XmlElement@ combatElem = modState.getFirstElementByTagName("combat");
		if (combatElem !is null) {
			m_killCount = combatElem.getIntAttribute("kill_count");
			deserializeKillCounter(combatElem, "blast", m_blastKillsByMap);
			deserializeKillCounter(combatElem, "stab", m_stabKillsByMap);
			deserializeKillCounter(combatElem, "roadkill", m_roadkillsByMap);
			_log("[AP] Restored combat: " + m_killCount + " kills, " +
				m_blastKillsByMap.getKeys().size() + " blast maps, " +
				m_stabKillsByMap.getKeys().size() + " stab maps, " +
				m_roadkillsByMap.getKeys().size() + " roadkill maps");
		}
	}

	protected void deserializeKillCounter(const XmlElement@ parent, string tag, dictionary@ d) {
		const XmlElement@ elem = parent.getFirstElementByTagName(tag);
		if (elem is null) return;
		array<const XmlElement@>@ ms = elem.getElementsByTagName("map");
		for (uint i = 0; i < ms.size(); i++) {
			string id = ms[i].getStringAttribute("id");
			if (id.length() == 0) continue;
			// Backwards-compat: old saves had no `count` attribute (set semantics).
			// Treat absent count as the current threshold so the check stays sent.
			int n = ms[i].getIntAttribute("count");
			if (n <= 0) n = 1;
			d.set(id, n);
		}
	}

	// ============================================================
	//  UTILITIES
	// ============================================================
	protected void sendChat(string message) {
		sendFactionMessage(m_metagame, 0, "[AP] " + message);
	}
}
